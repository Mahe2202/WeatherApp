//
//  CityList.swift
//  WeatherApp
//
//  Created by Udhayakumar on 05/11/22.
//

import Foundation


var cityList : [(cityName: String , lat: String, lon: String)] =
               [(cityName: "Mumbai",lat : "18.987807", lon: "72.836447"),
                (cityName: "Dehli",lat : "28.651952", lon: "77.231495"),
                (cityName: "Kolkata",lat : "22.562627", lon: "88.363044"),
                (cityName: "Chennai",lat : "13.084622", lon: "80.248357"),
                (cityName: "Bangalore",lat : "12.977063", lon: "77.587106"),
                (cityName: "Hyderabad",lat : "17.384052", lon: "78.456355")
               ]


